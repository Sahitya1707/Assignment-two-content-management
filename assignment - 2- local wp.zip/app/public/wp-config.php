<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '[:>lvof>g.{.Z_J-nR4`Gek;q,z_[8%4yJI^0L&r-][o?#qqIBL7ZI_$NQ_7)q1S' );
define( 'SECURE_AUTH_KEY',   '`x7gi=If1L<jCw(bYA>g+pI60_*% q}#GVXSrdbkd *2$Ejh5kMhmBU&m?y~SN[=' );
define( 'LOGGED_IN_KEY',     '$PhHLSh}f!bG_- myv=&lO.LtuUQ^lU(8>NzjC?S$EUG>byvq2s0Qp9UHw:yVqm3' );
define( 'NONCE_KEY',         '~zi`|Uz 1&/jEqf54 jXb/5r, Aoq#CU^l@Q^ `Af*LN7,4f)CbFaw*1Oe3+W8mK' );
define( 'AUTH_SALT',         'A$DV-Zu|zp3Uc!Wv@li7U/,hU@6)N= 4e]d#S:([,Qi-;5hTnzw-R9L(|<WEiyU#' );
define( 'SECURE_AUTH_SALT',  '$V|bsBM}}YfWeTVZE7t5f:5N)XZxXV!KnTSK:y6>aj(@3vzrw6*!z3k4.Z[jrn6(' );
define( 'LOGGED_IN_SALT',    'tJG}La+X-&y)QA`)]eP5^S0fCH.#X.4hG:O&Hm],Dz9s0d4YGIP%{yv;&heA=KF/' );
define( 'NONCE_SALT',        'R&vA3e+XahFx+>_7qe3vqL[vcM3,M[2-740: %k#lso@lY:4|t0pGI/b?O6;[^}O' );
define( 'WP_CACHE_KEY_SALT', '{}Z>!dt;?K+@2mK05C2s.fX(i<TaU?bO,]fxvT+U|?W=>A)m4erY;hI.$bhAc n@' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'WP_ENVIRONMENT_TYPE', 'local' );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
